import { Check } from "lucide-react";

export default function AboutUs() {
  const features = [
    {
      title: "Integrity First",
      description: "Transparent and honest in every deal",
      color: "bg-primary"
    },
    {
      title: "Win-Win Solutions", 
      description: "Benefits for all parties involved",
      color: "bg-accent"
    },
    {
      title: "Fast Process",
      description: "Quick closings when you need them", 
      color: "bg-blue-500"
    },
    {
      title: "Expert Network",
      description: "Connecting the right people",
      color: "bg-purple-500"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white scroll-mt-16" data-testid="about-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="about-title">
            About Nykson Capital
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="about-subtitle">
            We're more than investors — we're problem solvers committed to creating win-win real estate solutions.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Professional real estate team collaborating" 
              className="rounded-2xl shadow-lg w-full h-auto"
              data-testid="about-image"
            />
          </div>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-semibold text-foreground mb-4" data-testid="mission-title">
                Our Mission
              </h3>
              <p className="text-muted-foreground leading-relaxed" data-testid="mission-text">
                At Nykson Capital, we help property owners find fast, fair solutions while connecting investors 
                with profitable opportunities. Founded with integrity and guided by professionalism, we've built 
                a system that benefits every side of the transaction.
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start space-x-3" data-testid={`feature-${index}`}>
                  <div className={`w-8 h-8 ${feature.color} rounded-full flex items-center justify-center flex-shrink-0 mt-1`}>
                    <Check className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{feature.title}</h4>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
