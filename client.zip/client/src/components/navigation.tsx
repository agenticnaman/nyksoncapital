import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import logoPath from "@assets/White Illustrative Construction Logo-modified_1758373342537.png";

export default function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: "Home", href: "/" },
    { name: "Features", href: "/features" },
    { name: "Properties", href: "/properties" },
    { name: "Contact", href: "/contact" },
  ];

  const NavLink = ({ href, children, mobile = false, onClick }: { href: string; children: React.ReactNode; mobile?: boolean; onClick?: () => void }) => {
    const isActive = location === href;
    const baseClasses = mobile 
      ? "block px-3 py-2 font-medium transition-colors" 
      : "font-medium transition-colors";
    const activeClasses = isActive 
      ? "text-primary" 
      : "text-muted-foreground hover:text-primary";
    
    return (
      <Link href={href} className={`${baseClasses} ${activeClasses}`} data-testid={`nav-link-${children?.toString().toLowerCase()}`} onClick={onClick}>
        {children}
      </Link>
    );
  };

  return (
    <nav className="bg-white shadow-sm border-b border-border sticky top-0 z-50" data-testid="navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center" data-testid="logo-link">
            <div className="flex-shrink-0 flex items-center">
              <img className="h-10 w-auto" src={logoPath} alt="Nykson Capital Logo" />
              <span className="ml-3 text-xl font-bold text-foreground">Nykson Capital</span>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <NavLink key={item.href} href={item.href}>
                {item.name}
              </NavLink>
            ))}
            <Link href="/contact">
              <Button 
                className="bg-primary text-primary-foreground hover:bg-accent"
                data-testid="button-get-cash-offer"
              >
                Get Cash Offer
              </Button>
            </Link>
          </div>
          
          {/* Mobile menu */}
          <div className="md:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" data-testid="mobile-menu-button">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col space-y-4 mt-6">
                  {navItems.map((item) => (
                    <NavLink key={item.href} href={item.href} mobile onClick={() => setIsOpen(false)}>
                      {item.name}
                    </NavLink>
                  ))}
                  <Link href="/contact" onClick={() => setIsOpen(false)}>
                    <Button 
                      className="w-full bg-primary text-primary-foreground hover:bg-accent mt-4"
                      data-testid="mobile-get-cash-offer"
                    >
                      Get Cash Offer
                    </Button>
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
