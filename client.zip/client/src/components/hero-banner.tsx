import { Button } from "@/components/ui/button";
import { Home, Handshake, TrendingUp, Shield } from "lucide-react";
import { Link } from "wouter";

export default function HeroBanner() {
  return (
    <section className="relative bg-gradient-to-br from-muted to-white hero-pattern py-20 lg:py-32" data-testid="hero-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6" data-testid="hero-headline">
              Turning Properties Into{" "}
              <span className="text-primary">Profitable Opportunities</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl" data-testid="hero-subtext">
              We partner with motivated sellers, investors, and rehabbers to create win-win solutions in San
              Antonio and beyond. Fast, transparent, and professional — that's how real estate should be.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/contact">
                <Button 
                  size="lg" 
                  className="bg-primary text-primary-foreground hover:bg-accent shadow-lg"
                  data-testid="button-free-cash-offer"
                >
                  💰 Get Your Free Cash Offer Today
                </Button>
              </Link>
              <Button 
                variant="outline" 
                size="lg"
                data-testid="button-learn-more"
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Learn More
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl p-8" data-testid="hero-features-grid">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-primary/10 rounded-xl p-6 text-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                    <Home className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground">Fast Sales</h3>
                  <p className="text-sm text-muted-foreground">Close in 14 days</p>
                </div>
                <div className="bg-accent/10 rounded-xl p-6 text-center">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mx-auto mb-3">
                    <Handshake className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground">Win-Win</h3>
                  <p className="text-sm text-muted-foreground">Fair solutions</p>
                </div>
                <div className="bg-blue-500/10 rounded-xl p-6 text-center">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground">ROI Focus</h3>
                  <p className="text-sm text-muted-foreground">Maximize returns</p>
                </div>
                <div className="bg-purple-500/10 rounded-xl p-6 text-center">
                  <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground">Secure</h3>
                  <p className="text-sm text-muted-foreground">Trusted process</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
