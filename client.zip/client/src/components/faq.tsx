import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function FAQ() {
  const faqs = [
    {
      question: "Do you only buy in San Antonio?",
      answer: "While San Antonio is our primary market, we also evaluate deals in surrounding Texas cities. Contact us to discuss your specific location."
    },
    {
      question: "How fast can you close?",
      answer: "In many cases, as quickly as 10–14 days, depending on the title process. We work with experienced title companies to ensure smooth, fast closings."
    },
    {
      question: "Do I need to make repairs before selling?",
      answer: "No! We buy properties as-is, so you don't need to spend a dime on fixing anything. We handle all repairs and improvements after purchase."
    },
    {
      question: "What if I'm an investor?",
      answer: "Perfect — we'll bring you properties that fit your buy box. Just tell us your criteria, and we'll do the rest. We have a network of active investors we work with regularly."
    }
  ];

  return (
    <section className="py-20 gradient-bg" data-testid="faq-section">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="faq-title">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="faq-subtitle">
            Get answers to common questions about our process, timeline, and services.
          </p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <Accordion type="single" collapsible className="w-full" data-testid="faq-accordion">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-b border-border last:border-b-0">
                <AccordionTrigger 
                  className="px-8 py-6 text-left hover:bg-secondary/50 text-lg font-semibold"
                  data-testid={`faq-question-${index}`}
                >
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent 
                  className="px-8 pb-6 text-muted-foreground leading-relaxed"
                  data-testid={`faq-answer-${index}`}
                >
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
