import { Star, User } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Mark T.",
      role: "Rehab Investor",
      text: "Working with Nykson Capital was seamless. They handled everything and brought me a deal that fit my exact criteria. Closed without hassle.",
      color: "from-primary/5 to-accent/5"
    },
    {
      name: "Sarah L.", 
      role: "Property Seller",
      text: "I needed to sell fast, and they came through. Straightforward, honest, and professional. Highly recommend.",
      color: "from-accent/5 to-blue-500/5"
    }
  ];

  return (
    <section className="py-20 bg-white" data-testid="testimonials-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="testimonials-title">
            What Our Clients Say
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="testimonials-subtitle">
            Real testimonials from satisfied sellers and investors who've experienced our professional service.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className={`bg-gradient-to-br ${testimonial.color} rounded-2xl p-8 shadow-lg`}
              data-testid={`testimonial-${index}`}
            >
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-foreground">{testimonial.name}</h4>
                  <p className="text-muted-foreground">{testimonial.role}</p>
                </div>
                <div className="ml-auto flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
              </div>
              <blockquote className="text-muted-foreground italic leading-relaxed">
                "{testimonial.text}"
              </blockquote>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
