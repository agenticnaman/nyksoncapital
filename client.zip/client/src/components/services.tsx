import { Home, Handshake, FileText, Wrench } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: Home,
      title: "Direct Property Purchases",
      description: "We buy land and houses below market value for cash, offering sellers speed and certainty.",
      color: "bg-primary"
    },
    {
      icon: Handshake,
      title: "Investor Partnerships", 
      description: "Builders, rehabbers, and fix-and-flippers rely on us to bring them consistent deals that fit their exact criteria.",
      color: "bg-accent"
    },
    {
      icon: FileText,
      title: "Deal Structuring & Wholesaling",
      description: "With our contracts and buyer network, we create seamless assignments that generate value for all parties.",
      color: "bg-blue-500"
    },
    {
      icon: Wrench,
      title: "Rehab & Flip Support",
      description: "We connect rehabbers with distressed properties and help them maximize ROI through profitable exits.",
      color: "bg-purple-500"
    }
  ];

  return (
    <section id="services" className="py-20 gradient-bg" data-testid="services-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="services-title">
            Services We Provide
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="services-subtitle">
            Comprehensive real estate solutions designed to maximize value for sellers, investors, and rehabbers.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div 
                key={index} 
                className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow"
                data-testid={`service-${index}`}
              >
                <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mb-6`}>
                  <IconComponent className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
