import { Link } from "wouter";
import { Facebook, Linkedin, Twitter, Phone, Mail, MapPin } from "lucide-react";
import logoPath from "@assets/White Illustrative Construction Logo-modified_1758373342537.png";

export default function Footer() {
  return (
    <footer className="bg-foreground text-white py-16" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center mb-6">
              <img 
                className="h-10 w-auto brightness-0 invert" 
                src={logoPath} 
                alt="Nykson Capital Logo" 
                data-testid="footer-logo"
              />
              <span className="ml-3 text-xl font-bold">Nykson Capital</span>
            </div>
            <p className="text-gray-300 leading-relaxed mb-6" data-testid="footer-description">
              A privately held property investment firm dedicated to creating win-win real estate solutions. 
              We specialize in acquiring undervalued properties while providing investors with strategic opportunities.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="w-10 h-10 bg-primary rounded-full flex items-center justify-center hover:bg-accent transition-colors"
                data-testid="social-facebook"
              >
                <Facebook className="w-5 h-5 text-white" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-primary rounded-full flex items-center justify-center hover:bg-accent transition-colors"
                data-testid="social-linkedin"
              >
                <Linkedin className="w-5 h-5 text-white" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-primary rounded-full flex items-center justify-center hover:bg-accent transition-colors"
                data-testid="social-twitter"
              >
                <Twitter className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6" data-testid="quick-links-title">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link 
                  href="/" 
                  className="text-gray-300 hover:text-primary transition-colors"
                  data-testid="footer-link-home"
                >
                  Home
                </Link>
              </li>
              <li>
                <Link 
                  href="/features" 
                  className="text-gray-300 hover:text-primary transition-colors"
                  data-testid="footer-link-features"
                >
                  Features
                </Link>
              </li>
              <li>
                <Link 
                  href="/contact" 
                  className="text-gray-300 hover:text-primary transition-colors"
                  data-testid="footer-link-contact"
                >
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6" data-testid="contact-info-title">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3" data-testid="footer-phone">
                <Phone className="w-4 h-4 text-primary" />
                <span className="text-gray-300">(210) 555-CASH</span>
              </div>
              <div className="flex items-center space-x-3" data-testid="footer-email">
                <Mail className="w-4 h-4 text-primary" />
                <span className="text-gray-300">info@nyksoncapital.com</span>
              </div>
              <div className="flex items-center space-x-3" data-testid="footer-location">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-gray-300">San Antonio, TX</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-700 mt-12 pt-8 text-center">
          <p className="text-gray-300" data-testid="copyright">
            © 2024 Nykson Capital. All rights reserved. |{" "}
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a> |{" "}
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
          </p>
        </div>
      </div>
    </footer>
  );
}
