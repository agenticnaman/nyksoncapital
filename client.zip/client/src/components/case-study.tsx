import { AlertTriangle, Lightbulb, Trophy } from "lucide-react";

export default function CaseStudy() {
  return (
    <section className="py-20 gradient-bg" data-testid="case-study-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="case-study-title">
            Success Story
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto" data-testid="case-study-subtitle">
            Real results from our San Antonio market operations demonstrating our proven process.
          </p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* The Challenge */}
            <div className="text-center" data-testid="challenge-section">
              <div className="w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <AlertTriangle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4">The Challenge</h3>
              <p className="text-muted-foreground">
                A San Antonio property owner needed to sell quickly but couldn't get traction with traditional listings.
              </p>
            </div>
            
            {/* Our Solution */}
            <div className="text-center" data-testid="solution-section">
              <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Lightbulb className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4">Our Solution</h3>
              <p className="text-muted-foreground">
                Nykson Capital secured the property under contract, matched it with one of our cash buyers, 
                and closed in 14 days.
              </p>
            </div>
            
            {/* The Result */}
            <div className="text-center" data-testid="result-section">
              <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Trophy className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-4">The Result</h3>
              <div className="text-muted-foreground space-y-2">
                <p>✓ Seller walked away stress-free with cash</p>
                <p>✓ Buyer acquired property 30% below market</p>
                <p>✓ Both parties won with our solution</p>
              </div>
            </div>
          </div>
          
          {/* Results Summary */}
          <div className="mt-12 pt-8 border-t border-border">
            <div className="grid md:grid-cols-3 gap-6 text-center" data-testid="results-summary">
              <div>
                <div className="text-3xl font-bold text-primary mb-2">14 Days</div>
                <div className="text-muted-foreground">From contract to close</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent mb-2">30%</div>
                <div className="text-muted-foreground">Below market value</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-500 mb-2">100%</div>
                <div className="text-muted-foreground">Satisfaction rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
