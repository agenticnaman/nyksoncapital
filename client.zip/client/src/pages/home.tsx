import HeroBanner from "@/components/hero-banner";
import AboutUs from "@/components/about-us";
import Services from "@/components/services";
import CaseStudy from "@/components/case-study";
import Testimonials from "@/components/testimonials";
import FAQ from "@/components/faq";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  return (
    <>
      <title>Nykson Capital - Turning Properties Into Profitable Opportunities</title>
      <meta name="description" content="We partner with motivated sellers, investors, and rehabbers to create win-win real estate solutions in San Antonio and beyond. Fast, transparent, and professional." />
      
      <HeroBanner />
      <AboutUs />
      <Services />
      <CaseStudy />
      <Testimonials />
      <FAQ />
      
      {/* Call to Action Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-white" data-testid="cta-section">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6" data-testid="cta-title">
            Ready to Buy, Sell, or Invest?
          </h2>
          <p className="text-xl mb-8 opacity-90" data-testid="cta-description">
            Join the growing number of sellers, rehabbers, and investors who trust Nykson Capital to deliver real results.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-gray-100 shadow-lg"
                data-testid="button-cta-cash-offer"
              >
                💰 Get Cash Offer Now
              </Button>
            </Link>
            <Link href="/contact">
              <Button 
                variant="outline" 
                size="lg" 
                className="border-2 border-white text-white hover:bg-white hover:text-primary"
                data-testid="button-cta-call"
              >
                📞 Call Us Today
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
