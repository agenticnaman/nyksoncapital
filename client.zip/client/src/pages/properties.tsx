import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bed, Bath, Square, MapPin, DollarSign, Filter, Search } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import type { PropertyListing } from "@shared/schema";

export default function Properties() {
  const [searchFilters, setSearchFilters] = useState({
    minPrice: "",
    maxPrice: "",
    bedrooms: "",
    bathrooms: "",
    propertyType: "",
    city: "",
  });

  // Build query string from filters
  const queryString = new URLSearchParams(
    Object.entries(searchFilters)
      .filter(([_, value]) => value !== "" && value !== "any")
      .reduce((acc, [key, value]) => {
        acc[key] = value;
        return acc;
      }, {} as Record<string, string>)
  ).toString();

  const apiUrl = queryString ? `/api/properties?${queryString}` : "/api/properties";
  
  const { data: properties = [], isLoading } = useQuery<PropertyListing[]>({
    queryKey: [apiUrl],
  });

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(Number(price));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-500";
      case "under-contract":
        return "bg-yellow-500";
      case "sold":
        return "bg-gray-500";
      default:
        return "bg-blue-500";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4" data-testid="properties-title">
            Available Properties
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="properties-subtitle">
            Discover investment opportunities in San Antonio and surrounding Texas cities
          </p>
        </div>

        {/* Search Filters */}
        <Card className="mb-8" data-testid="search-filters">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Search Properties
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Min Price</label>
                <Input
                  type="number"
                  placeholder="100000"
                  value={searchFilters.minPrice}
                  onChange={(e) =>
                    setSearchFilters((prev) => ({ ...prev, minPrice: e.target.value }))
                  }
                  data-testid="input-min-price"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Max Price</label>
                <Input
                  type="number"
                  placeholder="500000"
                  value={searchFilters.maxPrice}
                  onChange={(e) =>
                    setSearchFilters((prev) => ({ ...prev, maxPrice: e.target.value }))
                  }
                  data-testid="input-max-price"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Bedrooms</label>
                <Select
                  value={searchFilters.bedrooms}
                  onValueChange={(value) =>
                    setSearchFilters((prev) => ({ ...prev, bedrooms: value }))
                  }
                >
                  <SelectTrigger data-testid="select-bedrooms">
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any</SelectItem>
                    <SelectItem value="1">1+</SelectItem>
                    <SelectItem value="2">2+</SelectItem>
                    <SelectItem value="3">3+</SelectItem>
                    <SelectItem value="4">4+</SelectItem>
                    <SelectItem value="5">5+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Bathrooms</label>
                <Select
                  value={searchFilters.bathrooms}
                  onValueChange={(value) =>
                    setSearchFilters((prev) => ({ ...prev, bathrooms: value }))
                  }
                >
                  <SelectTrigger data-testid="select-bathrooms">
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any</SelectItem>
                    <SelectItem value="1">1+</SelectItem>
                    <SelectItem value="2">2+</SelectItem>
                    <SelectItem value="3">3+</SelectItem>
                    <SelectItem value="4">4+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Property Type</label>
                <Select
                  value={searchFilters.propertyType}
                  onValueChange={(value) =>
                    setSearchFilters((prev) => ({ ...prev, propertyType: value }))
                  }
                >
                  <SelectTrigger data-testid="select-property-type">
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any</SelectItem>
                    <SelectItem value="single-family">Single Family</SelectItem>
                    <SelectItem value="condo">Condo</SelectItem>
                    <SelectItem value="townhouse">Townhouse</SelectItem>
                    <SelectItem value="multi-family">Multi Family</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">City</label>
                <Input
                  placeholder="San Antonio"
                  value={searchFilters.city}
                  onChange={(e) =>
                    setSearchFilters((prev) => ({ ...prev, city: e.target.value }))
                  }
                  data-testid="input-city"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Properties Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-64 bg-gray-200 rounded-t-lg" />
                <CardContent className="p-6">
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4" />
                    <div className="h-4 bg-gray-200 rounded w-1/2" />
                    <div className="h-4 bg-gray-200 rounded w-2/3" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : properties.length === 0 ? (
          <Card className="text-center py-16" data-testid="no-properties">
            <CardContent>
              <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No Properties Found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search filters or check back later for new listings.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow" data-testid={`property-card-${property.id}`}>
                <div className="relative">
                  <img
                    src={property.imageUrls?.[0] || "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"}
                    alt={`${property.address} - ${property.city}, ${property.state}`}
                    className="w-full h-64 object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className={`${getStatusColor(property.status)} text-white`}>
                      {property.status.replace("-", " ").toUpperCase()}
                    </Badge>
                  </div>
                  {property.isWholesale && (
                    <div className="absolute top-4 right-4">
                      <Badge variant="secondary">Wholesale</Badge>
                    </div>
                  )}
                </div>

                <CardHeader>
                  <CardTitle className="text-xl font-bold text-primary">
                    {formatPrice(property.price)}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {property.address}, {property.city}, {property.state} {property.zipCode}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-1">
                      <Bed className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{property.bedrooms} bed</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Bath className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{property.bathrooms} bath</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Square className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{property.squareFeet.toLocaleString()} sqft</span>
                    </div>
                  </div>

                  {property.description && (
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {property.description}
                    </p>
                  )}

                  {property.rentEstimate && (
                    <div className="flex items-center gap-1 mb-2">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      <span className="text-sm text-green-600 font-medium">
                        Est. Rent: {formatPrice(property.rentEstimate)}/mo
                      </span>
                    </div>
                  )}
                </CardContent>

                <CardFooter className="pt-0">
                  <Link href="/contact" className="w-full">
                    <Button className="w-full" data-testid={`button-inquire-property-${property.id}`}>
                      Inquire Now
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}

        {/* Call to Action */}
        {!isLoading && properties.length > 0 && (
          <Card className="mt-12 bg-primary text-primary-foreground">
            <CardContent className="p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Interested in These Properties?</h2>
              <p className="text-lg mb-6 opacity-90">
                Get in touch with our team to discuss investment opportunities and schedule property tours.
              </p>
              <Link href="/contact">
                <Button size="lg" variant="secondary" data-testid="button-contact-properties">
                  Contact Us Today
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}