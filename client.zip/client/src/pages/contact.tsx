import ContactForm from "@/components/contact-form";
import { Phone, Mail, MapPin } from "lucide-react";

export default function Contact() {
  return (
    <>
      <title>Contact Us - Nykson Capital</title>
      <meta name="description" content="Get your free cash offer today! Contact Nykson Capital for fast, fair real estate solutions in San Antonio and surrounding Texas cities." />
      
      <div className="min-h-screen">
        {/* Page Header */}
        <section className="py-20 bg-gradient-to-br from-muted to-white hero-pattern" data-testid="contact-header">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="contact-title">
              Ready to Get Started?
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="contact-subtitle">
              Contact us today for your free cash offer or to learn more about our investment opportunities.
            </p>
          </div>
        </section>

        {/* Contact Content */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <ContactForm />
              
              {/* Contact Information */}
              <div className="space-y-8">
                {/* Contact Details */}
                <div className="bg-card rounded-2xl p-8 shadow-lg" data-testid="contact-details">
                  <h3 className="text-2xl font-semibold text-foreground mb-6">Contact Information</h3>
                  <div className="space-y-6">
                    <div className="flex items-start space-x-4" data-testid="contact-phone">
                      <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center flex-shrink-0">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">Phone</h4>
                        <p className="text-muted-foreground">(210) 555-CASH</p>
                        <p className="text-sm text-muted-foreground">Available 7 days a week</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4" data-testid="contact-email">
                      <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center flex-shrink-0">
                        <Mail className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">Email</h4>
                        <p className="text-muted-foreground">info@nyksoncapital.com</p>
                        <p className="text-sm text-muted-foreground">We respond within 24 hours</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4" data-testid="contact-location">
                      <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">Service Area</h4>
                        <p className="text-muted-foreground">San Antonio & Surrounding Texas Cities</p>
                        <p className="text-sm text-muted-foreground">Expanding throughout Texas</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Service Area Map */}
                <div className="bg-card rounded-2xl p-8 shadow-lg" data-testid="service-area-map">
                  <h3 className="text-2xl font-semibold text-foreground mb-6">Our Service Area</h3>
                  <div className="rounded-xl overflow-hidden h-64">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d441027.7547887831!2d-98.7394322!3d29.424122!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x865c58af04d00eaf%3A0x856e13b10a016bc!2sSan%20Antonio%2C%20TX!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus"
                      width="100%"
                      height="256"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="San Antonio Service Area Map"
                      data-testid="embedded-google-map"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
