import { Zap, Settings, Shield, CheckCircle } from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: Zap,
      title: "Speed & Efficiency",
      description: "Close in days, not months. Our streamlined process eliminates traditional real estate delays, getting you to the closing table faster than ever before.",
      benefits: [
        "10-14 day closing timeline",
        "No lengthy inspection periods", 
        "Cash transactions for certainty"
      ],
      image: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      color: "bg-primary"
    },
    {
      icon: Settings,
      title: "Tailored Solutions",
      description: "Every deal is customized to meet the seller's and buyer's needs. We understand that one size doesn't fit all in real estate.",
      benefits: [
        "Flexible purchase terms",
        "Multiple exit strategies",
        "Custom investor matching"
      ],
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      color: "bg-accent"
    },
    {
      icon: Shield,
      title: "Trust & Transparency",
      description: "We communicate clearly, handle all paperwork, and ensure fair outcomes for everyone involved in the transaction.",
      benefits: [
        "Complete transparency in pricing",
        "Professional legal handling",
        "Verified track record"
      ],
      image: "https://images.unsplash.com/photo-1556742111-a301076d9d18?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      color: "bg-blue-500"
    }
  ];

  return (
    <>
      <title>Features - Nykson Capital</title>
      <meta name="description" content="Discover our key features: Speed & Efficiency, Tailored Solutions, and Trust & Transparency. Learn why investors and sellers choose Nykson Capital." />
      
      <div className="min-h-screen">
        {/* Page Header */}
        <section className="py-20 bg-gradient-to-br from-muted to-white hero-pattern" data-testid="features-header">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="features-title">
              Why Choose Nykson Capital
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="features-subtitle">
              Our unique approach delivers exceptional results for all parties involved in real estate transactions.
            </p>
          </div>
        </section>

        {/* Features Content */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-20">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                const isEven = index % 2 === 0;
                
                return (
                  <div 
                    key={index} 
                    className="grid lg:grid-cols-2 gap-12 items-center"
                    data-testid={`feature-${index}`}
                  >
                    <div className={isEven ? "order-2 lg:order-1" : "order-2"}>
                      <div className={`inline-flex items-center justify-center w-12 h-12 ${feature.color} rounded-xl mb-6`}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground mb-4" data-testid={`feature-title-${index}`}>
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed mb-6" data-testid={`feature-description-${index}`}>
                        {feature.description}
                      </p>
                      <div className="space-y-3">
                        {feature.benefits.map((benefit, benefitIndex) => (
                          <div 
                            key={benefitIndex} 
                            className="flex items-center space-x-3"
                            data-testid={`feature-benefit-${index}-${benefitIndex}`}
                          >
                            <CheckCircle className={`w-5 h-5 ${feature.color.replace('bg-', 'text-')}`} />
                            <span className="text-muted-foreground">{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className={isEven ? "order-1 lg:order-2" : "order-1"}>
                      <img 
                        src={feature.image} 
                        alt={feature.title} 
                        className="rounded-2xl shadow-lg w-full h-auto"
                        data-testid={`feature-image-${index}`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
